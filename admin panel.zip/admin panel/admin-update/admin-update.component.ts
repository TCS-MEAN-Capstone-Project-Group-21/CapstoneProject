import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-update',
  templateUrl: './admin-update.component.html',
  styleUrls: ['./admin-update.component.css']
})
export class AdminUpdateComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

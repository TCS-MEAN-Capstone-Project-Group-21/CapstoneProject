import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-admin',
  templateUrl: './update-admin.component.html',
  styleUrls: ['./update-admin.component.css']
})
export class UpdateAdminComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
